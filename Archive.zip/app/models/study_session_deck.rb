class StudySessionDeck < ApplicationRecord
  belongs_to :study_session
  belongs_to :deck
end
