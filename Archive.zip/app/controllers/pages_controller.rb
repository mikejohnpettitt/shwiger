class PagesController < ApplicationController
end
