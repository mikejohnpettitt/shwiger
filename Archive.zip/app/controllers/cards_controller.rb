class CardsController < ApplicationController
end
